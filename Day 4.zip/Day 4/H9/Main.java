package com.cognizant.main;

import java.util.*;


public class Main {
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<Integer>();
		for(Integer i = 100;i <= 150;i++) 
		{
			numbers.add(i);
			numbers.add(i-1);
		}
		numbers.stream().distinct().forEach((n)->System.out.println(n));
	}
}