import java.util.*;


public class Main {
	public static void main(String[] args) {
		List<Integer> numbers = new ArrayList<Integer>();
		for(Integer i = 85;i <= 110;i++) 
		{
			numbers.add(i);
		}
		Double ans = 
		(Double) (numbers.stream().map((a) -> a*a).filter((a) -> a > 10000))
							.mapToInt(val -> val).average().getAsDouble();
		System.out.println(ans);
		
	}
}