package employee;

import java.io.*;
import java.util.*;
 
class employee{
	int age;

	String name;

	public int getAge() {
		return age;
	}

	

	public String getName() {
		return name;
	}

	

	@Override
	public String toString() {
		return "employee [age=" + this.getAge() + ", name=" + this.getName() + "]";
	}
	employee(String n, int a)
	{
	  name=n;
	  age=a;
	}

}
public class sortemployee {
	public static void main(String[] args)
	{
	List<employee> emplist= new ArrayList<employee>();
	emplist.add(new employee("Rohith",50));
	emplist.add(new employee("Dhanan",22));
	emplist.add(new employee("Gowri",80));
	emplist.add(new employee("Deepak",25));
	emplist.add(new employee("Satheesh",20));
	emplist.add(new employee("Prakash",28));
	
	emplist.sort((employee e1,employee e2)->e1.getAge()-e2.getAge());
	emplist.forEach((c)->System.out.println(c));
	
	
	
	}
}

