package employee;

import java.io.*;
import java.util.*;
 
class employee{
	int age;

	String name;

	public int getAge() {
		return age;
	}

	

	public String getName() {
		return name;
	}

	

	@Override
	public String toString() {
		return "employee [age=" + this.getAge() + ", name=" + this.getName() + "]";
	}
	employee(String n, int a)
	{
	  name=n;
	  age=a;
	}

}
public class countemployee {
    
	public static void main(String[] args)
	{
	List<employee> emplist= new ArrayList<employee>();
	emplist.add(new employee("Rohith",50));
	emplist.add(new employee("Dhanan",22));
	emplist.add(new employee("Gowri",25));
	emplist.add(new employee("Deepak",18));
	emplist.add(new employee("Satheesh",25));
	emplist.add(new employee("Prakash",20));
	
	long count = emplist.stream().filter(c -> c.getAge() == 25).count();
	System.out.println(count);
	
	
	
	
	}
}

