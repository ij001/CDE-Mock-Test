import java.util.*;
import java.util.stream.Collectors;
public class Employee {
	private String name;
	private int age;
	public Employee(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> list= new ArrayList<Employee>();
		Employee obj= new Employee("Mary",30);
		Employee obj1= new Employee("abc",56);
		Employee obj2= new Employee("uf",21);
		Employee obj3= new Employee("bru",25);
		Employee obj4= new Employee("kich",25);
		list.add(obj);
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		
		
		
		list.stream().filter(t-> t.getName().length()>0).forEach(t-> System.out.print(t.getName()+","));
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}
