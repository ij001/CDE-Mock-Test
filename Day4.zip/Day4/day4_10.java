10.Will the Following Code Compile? Give Explanation
@FunctionalInterface
public interface Function2<T, U, V> {
    public V apply(T t, U u);
 
    default void count() {
        // increment counter
    }
}

ANSWER:
	Yes,The above code will run without any errors. In java 8,we can have both default and static methods in the interface but should contain only one abstract method.
