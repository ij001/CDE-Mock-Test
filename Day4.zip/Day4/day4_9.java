import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
public class Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list= Arrays.asList(5,98,101,500,200,5,23,67,34,101,98);
		//double avg= list.stream().map(i->i*i).filter(i->i>10000).mapToDouble(i->i).average().getAsDouble();
		list= list.stream().distinct().collect(Collectors.toList());
		System.out.println(list);
	}

}
