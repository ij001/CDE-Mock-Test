package com.emp.main;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.emp.model.EmployeeModel;

public class Main {

	public static void main(String[] args)
	{
		EmployeeModel emp=new EmployeeModel("Jack",15);
		EmployeeModel em=new EmployeeModel("Mary",25);
		EmployeeModel employee=new EmployeeModel("Harry",22);
		ArrayList<EmployeeModel> elist=new ArrayList<EmployeeModel>();
		elist.add(emp);
		elist.add(em);
		elist.add(employee);

		//employee age greater than 20
		Stream<EmployeeModel> emplist=elist.stream().filter(e->e.getAge()>20);
		emplist.forEach(e->System.out.println("Employee with age greater than 20:"+e));
		
		//employee with age 25
		Stream<EmployeeModel> emplist1=elist.stream().filter(r->r.getAge()==25);
		System.out.println("Number of employee with age 25:"+emplist1.count());
		
		//employee with name Mary
		Stream<EmployeeModel> emplist2=elist.stream().filter(e->e.getName().equalsIgnoreCase("Mary"));
		emplist2.forEach(e->System.out.println("Employee with name 'Mary':"+e));
		
		//maximum age of employee
		Comparator<EmployeeModel> empcomp=Comparator.comparing(EmployeeModel::getAge);
		EmployeeModel maxAge=elist.stream().max(empcomp).get();
		System.out.println("Maximum age:"+maxAge);
		
		//sorted employee based on age
		List<EmployeeModel> sortEmp=elist.stream().sorted(Comparator.comparingInt(EmployeeModel::getAge)).collect(Collectors.toList());
		sortEmp.forEach(e->System.out.println("Sorted employee based on age: "+e));
		
		//joining of employee name with ,
		String empname=elist.stream().map(EmployeeModel::getName).collect(Collectors.joining(","));
		System.out.println("Joined employee name:"+empname);
		
		//grouping of employee name
		Map<String, Long> group=elist.stream().collect(Collectors.groupingBy(EmployeeModel::getName,Collectors.counting()));
		System.out.println("Grouped by employee name:"+group);
		
	}
}
