package com.number.main;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class NumberMain {

	public static void main(String[] args)
	{
		List<Integer> numlist=Arrays.asList(200,540,670,46,3,200);
		OptionalDouble avg=numlist.stream().mapToInt(num->num.intValue()).filter(n->n*n>10000).average();
		System.out.println("Average:"+avg);
		
		List<Integer> reslist=numlist.stream().distinct().collect(Collectors.toList());
		System.out.println("List after removing duplicates:"+reslist);
		
	}
}
