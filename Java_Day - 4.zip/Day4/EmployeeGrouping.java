import java.util.*;
import java.util.stream.Collectors;
 
class Employee{

	int age;
	String name;

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	Employee(String name, int age)
	{
	  this.name=name;
	  this.age=age;
	}

}
public class EmployeeGrouping {
    
	public static void main(String[] args)	{
	
		List<Employee> empList= new ArrayList<Employee>();
		empList.add(new Employee("Janani",19));
		empList.add(new Employee("Deepak",20));
		empList.add(new Employee("Janani",60));
		empList.add(new Employee("Deepak",21));
		empList.add(new Employee("Janani",90));
		empList.add(new Employee("Deepak",1000));
		empList.add(new Employee("Janani",20));
	
        empList.stream().collect(Collectors.groupingBy(Employee::getName)).forEach((empName, empObj) -> 
                                                                                                {
                                                                                                    System.out.println("Name:"+empName+"Age:");
                                                                                                    for(Employee emp : empObj){
                                                                                                        System.out.println(emp.getAge());
                                                                                                    }
                                                                                                });
	}
}

