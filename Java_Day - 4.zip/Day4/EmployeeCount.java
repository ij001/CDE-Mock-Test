import java.util.*;
 
class Employee{

	int age;
	String name;

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	Employee(String name, int age)
	{
	  this.name=name;
	  this.age=age;
	}

}
public class EmployeeCount {
    
	public static void main(String[] args)	{
	
		List<Employee> empList= new ArrayList<Employee>();
		empList.add(new Employee("Janani",25));
		empList.add(new Employee("Deepak",25));
		empList.add(new Employee("Rohith",60));
		empList.add(new Employee("Dhanan",21));
		empList.add(new Employee("Gowri",90));
		empList.add(new Employee("Satheesh",1000));
		empList.add(new Employee("Prakash",20));
	
		long count = empList.stream().filter(emp -> emp.getAge() == 25).count();
		System.out.println(count);
	}
}

