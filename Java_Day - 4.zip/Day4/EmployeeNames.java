import java.util.*;
import java.util.stream.Collectors;
 
class Employee{

	int age;
	String name;

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	Employee(String name, int age)
	{
	  this.name=name;
	  this.age=age;
	}

}
public class EmployeeNames {
    
	public static void main(String[] args)	{
	
		List<Employee> empList= new ArrayList<Employee>();
		empList.add(new Employee("Janani",19));
		empList.add(new Employee("Deepak",20));
		empList.add(new Employee("Rohith",60));
		empList.add(new Employee("Dhanan",21));
		empList.add(new Employee("Gowri",90));
		empList.add(new Employee("Satheesh",1000));
		empList.add(new Employee("Prakash",20));
	
		String nameJoinedUsingComma = empList.stream().map(emp -> emp.getName()).collect(Collectors.joining(","));
		System.out.println(nameJoinedUsingComma);

	}
}

