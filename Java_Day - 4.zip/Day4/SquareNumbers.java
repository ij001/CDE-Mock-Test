import java.util.*;
import java.util.stream.*;

public class SquareNumbers{
    public static void main(String[] args){
        List<Integer> numbersList = Arrays.asList(1123,1234,545,23423,34545,22,342,4542,2322,23,99,101);
        double average = numbersList.stream().map(number -> number * number).filter(number -> number > 10000).mapToDouble(val -> val).average().orElse(0.0);
        System.out.println(average);
    }
}