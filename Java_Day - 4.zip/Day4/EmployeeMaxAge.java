import java.util.*;
import java.util.stream.Collectors;
 
class Employee{

	int age;
	String name;

	public int getAge() {
		return age;
	}

	public String getName() {
		return name;
	}

	Employee(String name, int age)
	{
	  this.name=name;
	  this.age=age;
	}

}
public class EmployeeMaxAge{
    
	public static void main(String[] args)	{
	
		List<Employee> empList= new ArrayList<Employee>();
		empList.add(new Employee("Janani",25));
		empList.add(new Employee("Deepak",25));
		empList.add(new Employee("Rohith",60));
		empList.add(new Employee("Mary",21));
		empList.add(new Employee("Gowri",90));
		empList.add(new Employee("Satheesh",1000));
		empList.add(new Employee("Prakash",20));
	
		Optional<Employee> maxAge = empList.stream()
            					.collect(Collectors.maxBy(Comparator.comparing(Employee::getAge)));
    	System.out.println((maxAge.isPresent() ? maxAge.get().getName()+" "+maxAge.get().getAge() : "Not Applicable"));
	}
}

