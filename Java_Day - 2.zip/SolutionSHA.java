import java.io.*;
import java.util.*;
import java.security.*;
public class Solution {

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc = new Scanner(System.in);
        MessageDigest msg = MessageDigest.getInstance("SHA-256");
        msg.reset();
        msg.update(sc.nextLine().getBytes());
        for (byte b : msg.digest()) {
            System.out.print(String.format("%02x", b));
        }
       
    }
}